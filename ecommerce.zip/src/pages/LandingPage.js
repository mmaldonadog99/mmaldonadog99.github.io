import { useCallback } from "react";
import styles from "./LandingPage.module.css";

const LandingPage = () => {
  const onLandingPageContainerClick = useCallback(() => {
    // Please sync "Marcas" to the project
  }, []);

  return (
    <div className={styles.landingPage} onClick={onLandingPageContainerClick}>
      <div className={styles.landingPageChild} />
      <div className={styles.suscribeteYObten20DeDsctParent}>
        <div className={styles.suscribeteYObtenContainer}>
          <span>{`Suscribete y obten 20% de dscto en tu siguiente compra. `}</span>
          <span className={styles.suscribirse}>Suscribirse</span>
        </div>
        <img className={styles.frameIcon} alt="" src="/frame.svg" />
      </div>
      <div className={styles.image30Parent}>
        <img className={styles.image30Icon} alt="" src="/image-30@2x.png" />
        <div className={styles.frameParent}>
          <div className={styles.categoriasParent}>
            <div className={styles.categorias}>Categorias</div>
            <img className={styles.frameIcon1} alt="" src="/frame1.svg" />
          </div>
          <div className={styles.categorias}>Nosotros</div>
          <div className={styles.categorias}>Novedades</div>
          <div className={styles.categorias}>Marcas</div>
        </div>
        <div className={styles.frameGroup}>
          <img className={styles.frameIcon2} alt="" src="/frame2.svg" />
          <div className={styles.categorias}>Busca productos...</div>
        </div>
        <div className={styles.frameContainer}>
          <img className={styles.frameIcon2} alt="" src="/frame3.svg" />
          <img className={styles.frameIcon2} alt="" src="/frame4.svg" />
        </div>
      </div>
      <b className={styles.deliciasQueInspiran}>
        Delicias que inspiran, sabores que enamoran
      </b>
      <div
        className={styles.encuentraEnUn}
      >{`Encuentra en un solo lugar todas las fiambres, quesos, y accesorios que necesites. `}</div>
      <div className={styles.comprarAhoraWrapper}>
        <div className={styles.comprarAhora}>Comprar ahora</div>
      </div>
      <div className={styles.frameDiv}>
        <div className={styles.parent}>
          <b className={styles.categorias}>200+</b>
          <div className={styles.marcasReconocidas}>Marcas reconocidas</div>
        </div>
        <div className={styles.frameChild} />
        <div className={styles.parent}>
          <b className={styles.categorias}>2,000+</b>
          <div className={styles.marcasReconocidas}>
            Productos de alta calidad
          </div>
        </div>
        <div className={styles.frameChild} />
        <div className={styles.parent}>
          <b className={styles.categorias}>30,000+</b>
          <div className={styles.marcasReconocidas}>Clientes satisfechos</div>
        </div>
      </div>
      <div className={styles.landingPageItem} />
      <div className={styles.group1}>
        <img className={styles.image15Icon} alt="" src="/image-15@2x.png" />
      </div>
      <b className={styles.novedades1}>Novedades</b>
      <b className={styles.msVendidos}>Más vendidos</b>
      <b className={styles.loQueDicen}>Lo que dicen nuestros clientes</b>
      <div className={styles.frameParent1}>
        <div className={styles.starParent}>
          <img className={styles.frameInner} alt="" src="/star-1.svg" />
          <img className={styles.frameInner} alt="" src="/star-2.svg" />
          <img className={styles.frameInner} alt="" src="/star-3.svg" />
          <img className={styles.frameInner} alt="" src="/star-4.svg" />
          <img className={styles.frameChild3} alt="" src="/star-5.svg" />
        </div>
        <div className={styles.categorias}>
          <span>4.5/</span>
          <span className={styles.span}>5</span>
        </div>
      </div>
      <div className={styles.frameParent2}>
        <div className={styles.starParent}>
          <img className={styles.frameInner} alt="" src="/star-1.svg" />
          <img className={styles.frameInner} alt="" src="/star-2.svg" />
          <img className={styles.frameInner} alt="" src="/star-3.svg" />
          <img className={styles.frameChild3} alt="" src="/star-51.svg" />
        </div>
        <div className={styles.categorias}>
          <span>3.5/</span>
          <span className={styles.span}>5</span>
        </div>
      </div>
      <div className={styles.frameParent3}>
        <div className={styles.starParent}>
          <img className={styles.frameInner} alt="" src="/star-1.svg" />
          <img className={styles.frameInner} alt="" src="/star-2.svg" />
          <img className={styles.frameInner} alt="" src="/star-3.svg" />
          <img className={styles.frameInner} alt="" src="/star-4.svg" />
          <img className={styles.frameChild3} alt="" src="/star-5.svg" />
        </div>
        <div className={styles.categorias}>
          <span>4.5/</span>
          <span className={styles.span}>5</span>
        </div>
      </div>
      <div className={styles.frameParent4}>
        <div className={styles.starParent}>
          <img className={styles.frameInner} alt="" src="/star-1.svg" />
          <img className={styles.frameInner} alt="" src="/star-2.svg" />
          <img className={styles.frameInner} alt="" src="/star-3.svg" />
          <img className={styles.frameInner} alt="" src="/star-4.svg" />
          <img className={styles.frameChild3} alt="" src="/star-5.svg" />
        </div>
        <div className={styles.categorias}>
          <span>4.5/</span>
          <span className={styles.span}>5</span>
        </div>
      </div>
      <b className={styles.jamnDePechuga}>Jamón de Pechuga Zimmerman</b>
      <b className={styles.jamnIbericoEnrique}>Jamón Iberico Enrique Tomas</b>
      <b className={styles.surtidoEspaolLa}>Surtido Español La Tapería</b>
      <b className={styles.jamnIbericoLa}>Jamón Iberico La Bellota 60g</b>
      <div className={styles.s80XKgWrapper}>
        <b className={styles.categorias}>S./80 x kg</b>
      </div>
      <div className={styles.s56Parent}>
        <b className={styles.categorias}>S./56</b>
        <b className={styles.s80}>S./80</b>
        <div className={styles.wrapper}>
          <div className={styles.comprarAhora}>-30%</div>
        </div>
      </div>
      <div className={styles.s480Parent}>
        <b className={styles.categorias}>S./480</b>
        <b className={styles.s80}>S./600</b>
        <div className={styles.wrapper}>
          <div className={styles.comprarAhora}>-20%</div>
        </div>
      </div>
      <b className={styles.s204}>S./204</b>
      <div className={styles.wrapper1}>
        <div className={styles.comprarAhora}>-20%</div>
      </div>
      <div className={styles.frameParent5}>
        <div className={styles.starParent}>
          <img className={styles.frameInner} alt="" src="/star-1.svg" />
          <img className={styles.frameInner} alt="" src="/star-2.svg" />
          <img className={styles.frameInner} alt="" src="/star-3.svg" />
          <img className={styles.frameInner} alt="" src="/star-4.svg" />
          <img className={styles.frameInner} alt="" src="/star-52.svg" />
        </div>
        <div className={styles.categorias}>
          <span>5.0/</span>
          <span className={styles.span}>5</span>
        </div>
      </div>
      <div className={styles.frameParent6}>
        <div className={styles.starParent}>
          <img className={styles.frameInner} alt="" src="/star-1.svg" />
          <img className={styles.frameInner} alt="" src="/star-2.svg" />
          <img className={styles.frameInner} alt="" src="/star-3.svg" />
          <img className={styles.frameInner} alt="" src="/star-4.svg" />
        </div>
        <div className={styles.categorias}>
          <span>4.0/</span>
          <span className={styles.span}>5</span>
        </div>
      </div>
      <div className={styles.frameParent7}>
        <div className={styles.starParent}>
          <img className={styles.frameInner} alt="" src="/star-1.svg" />
          <img className={styles.frameInner} alt="" src="/star-2.svg" />
          <img className={styles.frameInner} alt="" src="/star-3.svg" />
        </div>
        <div className={styles.categorias}>
          <span>3.0/</span>
          <span className={styles.span}>5</span>
        </div>
      </div>
      <div className={styles.frameParent8}>
        <div className={styles.starParent}>
          <img className={styles.frameInner} alt="" src="/star-1.svg" />
          <img className={styles.frameInner} alt="" src="/star-2.svg" />
          <img className={styles.frameInner} alt="" src="/star-3.svg" />
          <img className={styles.frameInner} alt="" src="/star-4.svg" />
          <img className={styles.frameChild3} alt="" src="/star-5.svg" />
        </div>
        <div className={styles.categorias}>
          <span>4.5/</span>
          <span className={styles.span}>5</span>
        </div>
      </div>
      <b className={styles.jamnInglesCasa}>Jamón Ingles Casa Europa</b>
      <b className={styles.packDeQuesos}>Pack de Quesos De Origen</b>
      <b className={styles.tocinoAhumadoZimmermann}>
        Tocino Ahumado Zimmermann
      </b>
      <b className={styles.jamnCrocanteCasa}>Jamón Crocante Casa Europa</b>
      <b className={styles.s14}>S./14</b>
      <b className={styles.s18}>S./18</b>
      <div className={styles.s799XKgWrapper}>
        <b className={styles.categorias}>S./ 79.9 x kg</b>
      </div>
      <b className={styles.s50}>S./50</b>
      <b className={styles.s1790}>S./17.90</b>
      <div className={styles.viewAllWrapper}>
        <div className={styles.comprarAhora}>View All</div>
      </div>
      <div className={styles.viewAllContainer}>
        <div className={styles.comprarAhora}>View All</div>
      </div>
      <div className={styles.landingPageInner} />
      <div className={styles.navegaPorCategoriaParent}>
        <b className={styles.navegaPorCategoria}>Navega por categoria</b>
        <div className={styles.image11Parent}>
          <img className={styles.image11Icon} alt="" src="/image-11@2x.png" />
          <b className={styles.fiambres}>Fiambres</b>
        </div>
        <div className={styles.accesoriosParent}>
          <b className={styles.fiambres}>Accesorios</b>
          <img className={styles.image13Icon} alt="" src="/image-13@2x.png" />
        </div>
        <div className={styles.image13Parent}>
          <img className={styles.image13Icon1} alt="" src="/image-131@2x.png" />
          <b className={styles.fiambres}>Quesos</b>
        </div>
        <div className={styles.image12Parent}>
          <img className={styles.image12Icon} alt="" src="/image-12@2x.png" />
          <b className={styles.fiambres}>Packs</b>
        </div>
      </div>
      <div className={styles.landingPageInner1}>
        <div className={styles.frameWrapper}>
          <div className={styles.frameParent9}>
            <div className={styles.starParent6}>
              <img className={styles.frameChild35} alt="" src="/star-11.svg" />
              <img className={styles.frameChild35} alt="" src="/star-21.svg" />
              <img className={styles.frameChild35} alt="" src="/star-31.svg" />
              <img className={styles.frameChild35} alt="" src="/star-41.svg" />
              <img className={styles.frameChild35} alt="" src="/star-53.svg" />
            </div>
            <div className={styles.frameParent10}>
              <div className={styles.categoriasParent}>
                <b className={styles.marceloH}>Marcelo H.</b>
                <img className={styles.frameIcon2} alt="" src="/frame5.svg" />
              </div>
              <div
                className={styles.losSaboresDe}
              >{`Los sabores de la tabla nunca me han decepcionado, todos los productos que he comprado por su pagina son de la mejor calidad y llegan a mi casa en tiempo record. `}</div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.landingPageInner2}>
        <div className={styles.frameWrapper}>
          <div className={styles.frameParent9}>
            <div className={styles.starParent6}>
              <img className={styles.frameChild35} alt="" src="/star-11.svg" />
              <img className={styles.frameChild35} alt="" src="/star-21.svg" />
              <img className={styles.frameChild35} alt="" src="/star-31.svg" />
              <img className={styles.frameChild35} alt="" src="/star-41.svg" />
              <img className={styles.frameChild35} alt="" src="/star-53.svg" />
            </div>
            <div className={styles.frameParent10}>
              <div className={styles.categoriasParent}>
                <b className={styles.marceloH}>Sarah M.</b>
                <img className={styles.frameIcon2} alt="" src="/frame5.svg" />
              </div>
              <div className={styles.losSaboresDe}>
                "I'm blown away by the quality and style of the clothes I
                received from Shop.co. From casual wear to elegant dresses,
                every piece I've bought has exceeded my expectations.”
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.landingPageInner3}>
        <div className={styles.frameWrapper}>
          <div className={styles.frameParent9}>
            <div className={styles.starParent6}>
              <img className={styles.frameChild35} alt="" src="/star-11.svg" />
              <img className={styles.frameChild35} alt="" src="/star-21.svg" />
              <img className={styles.frameChild35} alt="" src="/star-31.svg" />
              <img className={styles.frameChild35} alt="" src="/star-41.svg" />
              <img className={styles.frameChild35} alt="" src="/star-53.svg" />
            </div>
            <div className={styles.frameParent10}>
              <div className={styles.categoriasParent}>
                <b className={styles.marceloH}>Lucas P.</b>
                <img className={styles.frameIcon2} alt="" src="/frame5.svg" />
              </div>
              <div
                className={styles.losSaboresDe}
              >{`Encontrar un establecimiento que nunca me decepcione es una tarea que pense era imposible, pero desde que pido en Sabores de la tablea, esa percepción que tenia cambio. Tienen las mejores marcas al mejor precio. `}</div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.landingPageInner4}>
        <div className={styles.frameWrapper}>
          <div className={styles.frameParent9}>
            <div className={styles.starParent6}>
              <img className={styles.frameChild35} alt="" src="/star-11.svg" />
              <img className={styles.frameChild35} alt="" src="/star-21.svg" />
              <img className={styles.frameChild35} alt="" src="/star-31.svg" />
              <img className={styles.frameChild35} alt="" src="/star-41.svg" />
              <img className={styles.frameChild35} alt="" src="/star-53.svg" />
            </div>
            <div className={styles.frameParent10}>
              <div className={styles.categoriasParent}>
                <b className={styles.marceloH}>Lorena T.</b>
                <img className={styles.frameIcon2} alt="" src="/frame5.svg" />
              </div>
              <div
                className={styles.losSaboresDe}
              >{`Esta pagina se ha convertido en la que siempre pido cada vez que quiero hacer un brunch con mis amigas. Nunca me ha decepcionado, el delivery es rapido y los precios son los mejores del mercado. 100% satisfecha. `}</div>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.landingPageInner5}>
        <div className={styles.frameWrapper}>
          <div className={styles.frameParent9}>
            <div className={styles.starParent6}>
              <img className={styles.frameChild35} alt="" src="/star-11.svg" />
              <img className={styles.frameChild35} alt="" src="/star-21.svg" />
              <img className={styles.frameChild35} alt="" src="/star-31.svg" />
              <img className={styles.frameChild35} alt="" src="/star-41.svg" />
              <img className={styles.frameChild35} alt="" src="/star-53.svg" />
            </div>
            <div className={styles.frameParent10}>
              <div className={styles.categoriasParent}>
                <b className={styles.marceloH}>Macarena</b>
                <img className={styles.frameIcon2} alt="" src="/frame5.svg" />
              </div>
              <div className={styles.losSaboresDe}>
                "As someone who's always on the lookout for unique fashion
                pieces, I'm thrilled to have stumbled upon Shop.co. The
                selection of clothes is not only diverse but also on-point with
                the latest trends.”
              </div>
            </div>
          </div>
        </div>
      </div>
      <img
        className={styles.arrowDownBold1Icon}
        alt=""
        src="/arrowdownbold-1.svg"
      />
      <img
        className={styles.arrowDownBold2Icon}
        alt=""
        src="/arrowdownbold-2.svg"
      />
      <div className={styles.groupDiv}>
        <div className={styles.rectangleParent}>
          <div className={styles.groupChild} />
          <div className={styles.groupItem} />
          <div className={styles.enterateDeNuestrasNovedadesParent}>
            <b className={styles.enterateDeNuestras}>
              Enterate de nuestras novedades
            </b>
            <div className={styles.frameParent19}>
              <div className={styles.frameParent20}>
                <img className={styles.frameIcon2} alt="" src="/frame6.svg" />
                <div className={styles.categorias}>
                  Lucas valdivia@gmail.com
                </div>
              </div>
              <div className={styles.suscribeteWrapper}>
                <div className={styles.comprarAhora}>Suscribete</div>
              </div>
            </div>
          </div>
          <div className={styles.frameParent21}>
            <div className={styles.image31Parent}>
              <img
                className={styles.image30Icon}
                alt=""
                src="/image-31@2x.png"
              />
              <div className={styles.parent}>
                <div
                  className={styles.tenemosTodoLo}
                >{`Tenemos todo lo que necesitas para que tu comida sea inolvidable. `}</div>
              </div>
              <img className={styles.socialIcon} alt="" src="/social.svg" />
            </div>
            <div className={styles.helpMenuParent}>
              <div className={styles.helpMenu}>Nosotros</div>
              <div className={styles.aboutFeaturesWorksContainer}>
                <p className={styles.acercaDe}>{`Acerca de `}</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Características</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>{`Trabajos          `}</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Carreras</p>
              </div>
            </div>
            <div className={styles.helpMenuParent}>
              <div className={styles.helpMenu}>Ayuda</div>
              <div className={styles.aboutFeaturesWorksContainer1}>
                <p className={styles.acercaDe}>Soporte al cliente</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Delivery</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Terminos y condiciones</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Politica de privacidad</p>
              </div>
            </div>
            <div className={styles.helpMenuParent}>
              <div className={styles.helpMenu}>FAQ</div>
              <div className={styles.aboutFeaturesWorksContainer2}>
                <p className={styles.acercaDe}>Cuenta</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Gestión de pedidos</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Pedidos</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Pagos</p>
              </div>
            </div>
            <div className={styles.helpMenuParent}>
              <div className={styles.helpMenu}>Recursos</div>
              <div className={styles.aboutFeaturesWorksContainer1}>
                <p className={styles.acercaDe}>eBooks</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Tutoriales</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Blog</p>
                <p className={styles.acercaDe}>&nbsp;</p>
                <p className={styles.acercaDe}>Playlist de YT</p>
              </div>
            </div>
          </div>
          <div className={styles.badgeParent}>
            <img className={styles.badgeIcon} alt="" src="/badge.svg" />
            <img className={styles.badgeIcon} alt="" src="/badge1.svg" />
            <img className={styles.badgeIcon} alt="" src="/badge2.svg" />
            <img className={styles.badgeIcon} alt="" src="/badge3.svg" />
            <img className={styles.badgeIcon} alt="" src="/badge4.svg" />
          </div>
          <div className={styles.allRightsReserved}>
            Los sabores de la tabla © 2023, Todos los derechos reservados.
          </div>
        </div>
      </div>
      <img className={styles.image16Icon} alt="" src="/image-16@2x.png" />
      <img className={styles.image17Icon} alt="" src="/image-17@2x.png" />
      <img className={styles.image18Icon} alt="" src="/image-18@2x.png" />
      <img className={styles.image20Icon} alt="" src="/image-20@2x.png" />
      <img className={styles.image21Icon} alt="" src="/image-21@2x.png" />
      <img className={styles.image22Icon} alt="" src="/image-22@2x.png" />
      <img className={styles.image23Icon} alt="" src="/image-23@2x.png" />
      <img className={styles.image25Icon} alt="" src="/image-25@2x.png" />
      <img className={styles.image26Icon} alt="" src="/image-26@2x.png" />
      <img className={styles.image27Icon} alt="" src="/image-27@2x.png" />
      <img className={styles.image28Icon} alt="" src="/image-28@2x.png" />
      <img className={styles.image19Icon} alt="" src="/image-19@2x.png" />
      <img className={styles.image33Icon} alt="" src="/image-33@2x.png" />
    </div>
  );
};

export default LandingPage;
